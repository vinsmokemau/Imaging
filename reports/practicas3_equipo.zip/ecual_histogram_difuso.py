import numpy as np 
import matplotlib.pyplot as plt 
import skfuzzy as fuzzy 
from skimage import color,io,data

img = data.moon()
# gris = io.imread('calavera5.jpg',0)
# Adquirir imagen
gris = img
# gris = np.uint8(color.rgb2gray(gris) * 255)
#Convertir mangen en escala de grises 
[fil, col] = gris.shape
#Tamaño de la imagen

pixel = np.linspace(0, 255, 256)
#Vecto de pixels de 0 a 255

oscuros = fuzzy.zmf(pixel,25,75)
#conjunto difuzo -> Tipo zmf(Valor , Valor -> 1, Valor -> 0)
grises = fuzzy.gbellmf(pixel,50,3,120)
#conjunto difuzo -> Tipo zmf(Valor , Ancho -> 1, Pediente, Centro)
# grises = fuzzy.gbellmf(pixel, 75, 20, 140)
claros = fuzzy.smf(pixel,130,230) 
#conjunto difuzo -> Tipo zmf(Valor , Valor -> 0, Valor -> 1)

s1 = 30 #Singleton de Negro
s2 = 120 #Singleton de Gris
s3 = 250 #Singleton de blanco
new_gray = np.zeros(256) 
#Vector de nueva mascara de grises
for i in range(256):
    new_gray[i] =(oscuros[i]*s1+grises[i]*s2 + claros[i]*s3)/(oscuros[i] + grises[i] + claros[i])
    #Algoritmo de Defuzzificación
#Parte 2
ehf = np.zeros([fil,col])
#Vector de imagen de salida
for i in range(fil):
    for j in range(col):
        valor = gris[i,j]
        #Valor de imagen original
        ehf[i,j] = new_gray[valor]
        """ Pone el valor de imagen difusa en la posicion original
            y guardar en imagen de salida
        """ 
plt.figure(1)
plt.subplot(2, 2, 1)
plt.imshow(gris, cmap = "gray")
plt.title('Imagen original')
plt.axis('off')

plt.subplot(2, 2, 2)
plt.imshow(ehf, cmap = "gray")
plt.title('Imagen Procesada')
plt.axis('off')

plt.subplot(2, 2, 3)
plt.plot(oscuros)
plt.plot(grises)
plt.plot(claros)
plt.legend(["Oscuros","Gris","Blancos"])
plt.title('Rule-base Fuzzy')
plt.xlabel('Valor de pixel')
plt.ylabel('Umbral del valor')

plt.subplot(2,2,4)
plt.plot(new_gray)
plt.title('Repuesta Defuzzificación')
plt.xlabel('Valor de pixel')
plt.ylabel('Altura de pixel')

plt.show()
import matplotlib.pyplot as plt
import numpy as np 
from skimage import color,io,data

img = data.moon()
# img = io.imread('calavera5.jpg',0) 
#Leer imagen en color
[xl, yl] = img.shape 
#Medir tamañano de img
gris_img = img
# gris_img = np.uint8(color.rgb2gray(img) * 255) 
#Pasar a escala de grises

histograma = np.zeros(256) 
#Vector de histograma
for i in range(xl):
	for j in range(yl):
		posicion = gris_img[i, j]
        #Valor de gris de cada posicion
		histograma[posicion] = histograma[posicion] + 1
        #Acumular los valores seguna la posicon 

m = max(histograma)
#Máximo
X = [i for i, j in enumerate(histograma) if j == m]
#Moda
sig = 80 
#Sigma propuesto para ecuacion de gauss varible 

G = np.zeros(256)
T = np.zeros(256)
for i in range(256):
    #Campana de Gauss
    G[i] = (1/(np.sqrt(2*np.pi*sig)))*np.exp(-((i-300)**2)/(2.*(sig**2)))
    #Mutltopicacíon punto a punto de Gass * Histograma [posicion]
    T[i] = G[i]*histograma[i]


salida = np.zeros((xl, yl))
#Vector de salida
for x in range(xl):
    for y in range(yl):
        pos = gris_img[x, y]
        #Valor de gris de cada posición 
        salida[x, y] = np.uint8(T[pos])
        #Se asigana el valor de la ecualización imagen normalizando el valor de gris


print(G.shape)        
plt.figure(1)

plt.subplot(2,3,1)
plt.title("Histograma")
plt.xlabel('t')
plt.ylabel("Pixels")
plt.plot(histograma)

plt.subplot(2,3,2)
plt.title("Campana de Gauss Popuesta")
plt.xlabel('t')
plt.ylabel("Trasformación")
plt.plot(G)
plt.subplot(2,3,3)
plt.title("Transdormación")
plt.xlabel('t')
plt.ylabel("Valor Pixel")
plt.plot(T)



plt.subplot(2,3,5)
plt.title("Imagen Gris Original")
plt.axis('off')
plt.imshow(gris_img, cmap = 'gray')

plt.subplot(2,3,6)
plt.title("Imagen Transformada")
plt.axis('off')
plt.imshow(salida, cmap = 'gray')

plt.show()
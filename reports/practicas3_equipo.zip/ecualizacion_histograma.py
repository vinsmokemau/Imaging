from skimage import color,io,data
import numpy as np 
import matplotlib.pyplot as plt

# img = io.imread('calavera5.jpg',0) 
img = data.moon()
#Leer imagen en color
[xl, yl ] = img.shape 
#Medir tamañano de img
gris_img = img
# gris_img = np.uint8(color.rgb2gray(img) * 255) 
#Pasar a escala de grises

histograma = np.zeros(256) 
#Vector de histograma
for i in range(xl):
	for j in range(yl):
		posicion = gris_img[i, j]
        #Valor de gris de cada posicion
		histograma[posicion] = histograma[posicion] + 1
        #Acumular los valores seguna la posicon 

probabilidad = np.zeros(256) 
#Vector de probablidad
probabilidad = histograma / (xl * yl)
#Ecuación de probabilidad normalizada
ecual_histogram = probabilidad.cumsum()
#Ecualizacíon de histograma 
salida = np.zeros((xl, yl))
#Vector de salida
for x in range(xl):
    for y in range(yl):
        pos = gris_img[x, y]
        #Valor de gris de cada posición 
        salida[x, y] = np.uint8(ecual_histogram[pos] * 255)
        #Se asigana el valor de la ecualización imagen normalizando el valor de gris

plt.figure(1)

plt.subplot(2,2,1)
plt.title("Histograma")
plt.xlabel('t')
plt.ylabel("Pixels")
plt.plot(histograma)

plt.subplot(2,2,2)
plt.title("Ecualización de Histograma")
plt.xlabel('t')
plt.ylabel("Trasformación")
plt.plot(ecual_histogram)

plt.subplot(2,2,3)
plt.title("Imagen Original")
plt.axis('off')
plt.imshow(gris_img, cmap = 'gray')

plt.subplot(2,2,4)
plt.title("Imagen Transformada")
plt.axis('off')
plt.imshow(salida, cmap = 'gray')

plt.figure(2)

plt.subplot(2,1,1)
plt.title("Histograma")
plt.xlabel('Nivel de gris')
plt.ylabel("Pixels")
plt.plot(histograma)

plt.subplot(2,1,2)
plt.title("Ecualización de Histograma")
plt.xlabel('Nivel de gris')
plt.ylabel("Trasformación")
plt.plot(ecual_histogram)

plt.figure(3)

plt.subplot(1,3,1)
plt.title("Imagen Original")
plt.axis('off')
plt.imshow(img, cmap = 'gray')

plt.subplot(1,3,2)
plt.title("Imagen Gris Original")
plt.axis('off')
plt.imshow(gris_img, cmap = 'gray')

plt.subplot(1,3,3)
plt.title("Imagen Transformada")
plt.axis('off')
plt.imshow(salida, cmap = 'gray')

plt.show()